import pandas as pd
import numpy as np  # Import numpy to handle NaN
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report
import joblib
import os

# --- Configuration ---
DATA_FILE = os.path.join('data', 'heart.csv')
MODEL_FILE = 'heart_disease_model.joblib'
SCALER_FILE = 'scaler.joblib'


# Using the standard column names from the recommended Kaggle CSV
FEATURE_COLUMNS = [
    'age', 'sex', 'cp', 'trestbps', 'chol', 
    'fbs', 'restecg', 'thalach', 'exang', 
    'oldpeak', 'slope', 'ca', 'thal'
]


# Using the standard target column name
TARGET_COLUMN = 'target' 

def train_model():
    """
    Loads the dataset, trains a logistic regression model,
    and saves the model and scaler to disk.
    """
    print("Script started...")
    
    # 1. Load Data
    try:
        df = pd.read_csv(DATA_FILE)
        print(f"Successfully loaded {DATA_FILE}")
    except FileNotFoundError:
        print(f"Error: Data file not found at {DATA_FILE}")
        print("Please make sure 'heart.csv' is inside the 'backend/data/' folder.")
        return
    except Exception as e:
        print(f"Error loading {DATA_FILE}: {e}")
        return


    # This dataset uses '?' for missing values, especially in 'ca' and 'thal'
    df.replace('?', np.nan, inplace=True)
    print(f"Replaced '?' with NaN across the dataset.")

    # Check for required columns
    required_cols = FEATURE_COLUMNS + [TARGET_COLUMN]
    missing_cols = [col for col in required_cols if col not in df.columns]
    
    if missing_cols:
        print(f"Error: The dataset is missing the following required columns: {missing_cols}")
        print(f"Available columns are: {list(df.columns)}")
        return

    print("All required columns found.")

    # 2. Preprocess Data
    
    # --- Convert all feature and target columns to numeric ---
    # 'errors=coerce' turns any unmappable text (like the '?' we replaced) into NaN.
    try:
        for col in required_cols:
            df[col] = pd.to_numeric(df[col], errors='coerce')
        print("Converted all feature and target columns to numeric.")
    except Exception as e:
        print(f"Error during numeric conversion: {e}")
        return

    # --- Perform a SINGLE drop of all rows with NaN ---
    # This removes rows where '?' was present or any other conversion issue.
    original_len = len(df)
    df = df.dropna(subset=required_cols)
    new_len = len(df)
    
    if original_len > new_len:
        print(f"Dropped {original_len - new_len} rows that had any NaN values.")
    
    if new_len == 0:
        print("Error: After processing, no data remains. Check your CSV file.")
        return

    # This dataset uses 'target' column with 0 (no disease) and 1 (disease)
    # No extra processing needed for the target column.
    print(f"Target column '{TARGET_COLUMN}' processed. Value counts:")
    print(df[TARGET_COLUMN].value_counts())

    # Define our features (X) and target (y)
    X = df[FEATURE_COLUMNS]
    y = df[TARGET_COLUMN]

    # 3. Split Data
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
    print(f"Data split into {len(X_train)} training and {len(X_test)} testing samples.")

    # 4. Scale Features
    # We fit the scaler ONLY on the training data
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    # We transform the test data using the *same* scaler
    X_test_scaled = scaler.transform(X_test)
    print("Features scaled.")

    # 5. Train Model
    model = LogisticRegression(random_state=42, max_iter=1000)
    model.fit(X_train_scaled, y_train)
    print("Model training complete.")

    # 6. Evaluate Model
    y_pred = model.predict(X_test_scaled)
    accuracy = accuracy_score(y_test, y_pred)
    print("\n--- Model Evaluation ---")
    print(f"Accuracy: {accuracy * 100:.2f}%")
    print("Classification Report:")
    print(classification_report(y_test, y_pred))
    print("------------------------\n")

    # 7. Save Model and Scaler
    try:
        joblib.dump(model, MODEL_FILE)
        print(f"Model saved to {MODEL_FILE}")
        joblib.dump(scaler, SCALER_FILE)
        print(f"Scaler saved to {SCALER_FILE}")
    except Exception as e:
        print(f"Error saving model/scaler: {e}")

if __name__ == "__main__":
    train_model()


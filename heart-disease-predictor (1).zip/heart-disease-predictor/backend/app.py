from flask import Flask, request, jsonify
from flask_cors import CORS
import joblib
import numpy as np
import os

app = Flask(__name__)
# Enable CORS (Cross-Origin Resource Sharing)
# This allows your frontend (running from a file:// or different port)
# to make requests to this backend.
CORS(app)

# --- Load Model and Scaler ---
# We load the trained model and the scaler right when the app starts.
try:
    model = joblib.load('heart_disease_model.joblib')
    scaler = joblib.load('scaler.joblib')
    print("Model and scaler loaded successfully.")
except FileNotFoundError:
    print("Error: Model or scaler files not found.")
    print("Please run 'python model.py' first to train and save the files.")
    model = None
    scaler = None

# These are the feature names in the EXACT order the model was trained on.
# We'll use this to build the input array for prediction.
FEATURE_COLUMNS = [
    'age', 'sex', 'cp', 'trestbps', 'chol', 
    'fbs', 'restecg', 'thalach', 'exang', 
    'oldpeak', 'slope', 'ca', 'thal'
]

@app.route('/')
def home():
    # A simple route to check if the API is running.
    return "Heart Disease Predictor API is running!"

@app.route('/predict', methods=['POST'])
def predict():
    if not model or not scaler:
        return jsonify({'error': 'Model not loaded. Please run model.py first.'}), 500

    try:
        # 1. Get data from the frontend's JSON request
        data = request.get_json()
        print(f"Received data: {data}") # Log incoming data

        # 2. Check if all required features are present
        missing_features = [col for col in FEATURE_COLUMNS if col not in data]
        if missing_features:
            print(f"Error: Missing features {missing_features}")
            return jsonify({'error': f'Missing features: {", ".join(missing_features)}'}), 400
        
        # 3. Check for empty values
        empty_features = [col for col in FEATURE_COLUMNS if data.get(col) == '']
        if empty_features:
            print(f"Error: Empty values for {empty_features}")
            return jsonify({'error': f'Please fill out all fields. Missing: {", ".join(empty_features)}'}), 400

        # 4. Create the feature array in the correct order
        # Ensure values are numbers (float)
        input_features = []
        for col in FEATURE_COLUMNS:
            try:
                input_features.append(float(data[col]))
            except ValueError:
                print(f"Error: Invalid value for {col}")
                return jsonify({'error': f'Invalid value for {col}: "{data[col]}". Must be a number.'}), 400
            except TypeError:
                print(f"Error: Type error for {col} (value: {data[col]})")
                return jsonify({'error': f'Invalid type for {col}: "{data[col]}".'}), 400


        # 5. Convert to 2D NumPy array (model expects a 2D array)
        input_array = np.array(input_features).reshape(1, -1)

        # 6. Scale the features using the *same* scaler from training
        input_scaled = scaler.transform(input_array)

        # 7. Make prediction
        prediction = model.predict(input_scaled)
        # Get probability of having heart disease (class 1)
        probability = model.predict_proba(input_scaled)[0][1] 

        # 8. Format the response
        result = {
            'prediction': int(prediction[0]), # 0 (no disease) or 1 (disease)
            'probability': float(probability) # Probability of having disease
        }
        
        print(f"Prediction: {result}") # Log prediction
        return jsonify(result)

    except Exception as e:
        print(f"Error during prediction: {e}")
        return jsonify({'error': 'An error occurred during prediction.'}), 500

if __name__ == '__main__':
    # Get port from environment variable or default to 5000
    port = int(os.environ.get('PORT', 5000))
    # Run the app
    # host='0.0.0.0' makes it accessible on your local network
    app.run(host='0.0.0.0', port=port, debug=True)

